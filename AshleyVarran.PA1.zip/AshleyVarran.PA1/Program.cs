﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AshleyVarran.PA1

    //I have taken your class before I think.  THis seems really familure.  I could not figure out how to do it last time.
    //I hope I do better this time
    //I could not figure out the colors to save my life.
    //At least it works ish

{
    class Program
    
        {
            static String[] p2Board = new String[100];
            static String[] p1Board = new String[100];

            static String[] p2Hit = new String[100];
            static String[] p1Hit = new String[100];

           

            static int hitCounterP1 = 0;
            static int hitCounterP2 = 0;

        //Changed to true - read this in the book testing --- I dont think this is right.....
            static Boolean hasWon = true;


            static void initializeVariables()
            {
                for (int i = 0; i < 100; i++)
                {
                    p1Board[i] = " ";
                    p2Board[i] = " ";
                    p1Hit[i] = " ";
                    p2Hit[i] = " ";
                }
            }

            static void Main(string[] args)
            {

                initializeVariables();
                introduction();
                askData();
                goodBye();

            }

        private static void goodBye()
        {
            throw new NotImplementedException();
        }

        static void inputShipLocation()
            {
                Console.Clear();
                Console.WriteLine("This is the turn for Player 1! Player 2: Dont peak :) ");
                Console.ReadLine();
                Console.Clear();

                //if (selection.equals("N"))  ??? I cant figure out how to get to the next ship --- I think the boool ubove fixed it. TBA

              


                Console.WriteLine("Please select the location of your ship  based on the box #");
                drawBoard("P1");
                int selection = Convert.ToInt32(Console.ReadLine());
              

         
                p1Board[selection] = "S";
                p1Board[selection + 1] = "S";

             
                Console.WriteLine("Please select the location of your ship (Destroyer) based on the box #");
                drawBoard("P1");
                selection = Convert.ToInt32(Console.ReadLine());
              

                p1Board[selection] = "S";
                p1Board[selection + 1] = "S";
                p1Board[selection + 2] = "S";

           
                Console.WriteLine("Please select the location of your ship (Submarine) based on the box #");
                drawBoard("P1");
                selection = Convert.ToInt32(Console.ReadLine());
           

                p1Board[selection] = "S";
                p1Board[selection + 1] = "S";
                p1Board[selection + 2] = "S";

           
                Console.WriteLine("Please select the location of your ship (Destroyer) based on the box #");
                drawBoard("P1");
                selection = Convert.ToInt32(Console.ReadLine());
               

                p1Board[selection] = "S";
                p1Board[selection + 1] = "S";
                p1Board[selection + 2] = "S";
                p1Board[selection + 3] = "S";

            
                Console.WriteLine("Please select the location of your ship (battleship) based on the box #");
                drawBoard("P1");

            // Error while testing but still works ???

            selection = Convert.ToInt32(Console.ReadLine());
           

                p1Board[selection] = "B";
                p1Board[selection + 1] = "B";
                p1Board[selection + 2] = "B";
                p1Board[selection + 3] = "B";

          
                Console.WriteLine("Please select the location of your ship (Carrier) based on the box #");
                drawBoard("P1");
                selection = Convert.ToInt32(Console.ReadLine());
           

                p1Board[selection] = "S";
                p1Board[selection + 1] = "S";
                p1Board[selection + 2] = "S";
                p1Board[selection + 3] = "S";
                p1Board[selection + 4] = "S";

       

                Console.Clear();
                Console.WriteLine("Player 2! Your turn right now! Press any key to continue.");
                Console.ReadLine();

                Console.WriteLine("Please select the location of your ship (patrol) based on the box #");
                drawBoard("P1");
                selection = Convert.ToInt32(Console.ReadLine());
              

                p2Board[selection] = "S";
                p2Board[selection + 1] = "S";

                Console.WriteLine("Please select the location of your ship (Destroyer) based on the box #");
                drawBoard("P1");
                selection = Convert.ToInt32(Console.ReadLine());
              

                p2Board[selection] = "S";
                p2Board[selection + 1] = "S";
                p2Board[selection + 2] = "S";


                Console.WriteLine("Please select the location of your ship (Submarine) based on the box #");
                drawBoard("P1");
                selection = Convert.ToInt32(Console.ReadLine());
            

                p2Board[selection] = "S";
                p2Board[selection + 1] = "S";
                p2Board[selection + 2] = "S";

              
                Console.WriteLine("Please select the location of your ship (Destroyer) based on the box #");
                drawBoard("P1");
                selection = Convert.ToInt32(Console.ReadLine());
            

                p2Board[selection] = "S";
                p2Board[selection + 1] = "S";
                p2Board[selection + 2] = "S";
                p2Board[selection + 3] = "S";

           
                Console.WriteLine("Please select the location of your ship (battleship) based on the box #");
                drawBoard("P1");
                selection = Convert.ToInt32(Console.ReadLine());
               

                p2Board[selection] = "B";
                p2Board[selection + 1] = "B";
                p2Board[selection + 2] = "B";
                p2Board[selection + 3] = "B";

                Console.WriteLine("Please select the location of your ship (Carrier) based on the box #");
                drawBoard("P1");
                selection = Convert.ToInt32(Console.ReadLine());
            

                p2Board[selection] = "S";
                p2Board[selection + 1] = "S";
                p2Board[selection + 2] = "S";
                p2Board[selection + 3] = "S";
                p2Board[selection + 4] = "S";
         
            }

            static void promptHit()
            {
                Console.Clear();
                Console.WriteLine("Player 1: Please enter your selection based on the previous hit field.");
                drawBoard("P1Hit");
                int selection = Convert.ToInt32(Console.ReadLine());
                if (p2Board[selection] != " ")
                {
                    Console.WriteLine("HIT!");
                    p1Hit[selection] = "H";
                    hitCounterP1++;
                    if (hitCounterP1 == 21)
                        hasWon = true;
                }
                else
                {
                    Console.WriteLine("MISS!");
                    p1Hit[selection] = "M";
                }
                Console.WriteLine("\nPress any key to continue.");
                Console.ReadLine();
                Console.Clear();
                Console.WriteLine("Player 12 Please enter your selection based on the previous hit field.");
                drawBoard("P2Hit");
                selection = Convert.ToInt32(Console.ReadLine());
                if (p1Board[selection] != " ")
                {
                    Console.WriteLine("HIT!");
                    p2Hit[selection] = "H";
                    hitCounterP2++;
                    if (hitCounterP2 == 21)
                        hasWon = true;

                }
                else
                {
                    Console.WriteLine("MISS!");
                    p2Hit[selection] = "M";
                }
                Console.WriteLine("\nPress any key to continue.");
                Console.ReadLine();
            }

            static void askData()
            {
                inputShipLocation();
                while (hasWon)
                {
                    promptHit();

                }


            }
        // Board Works AAV 03/20
            static void drawBoard(String selection)
            {
                if (selection.Equals("P1"))
                {
                    for (int x = 0; x < 10; x++)
                    {
                        for (int i = 0; i < 10; i++)
                        {
                            Console.Write(p1Board[i + x] + "|");
                        }
                        Console.WriteLine();
                    }
                }
                else if (selection.Equals("P2"))
                {
                    for (int x = 0; x < 10; x++)
                    {
                        for (int i = 0; i < 10; i++)
                        {
                            Console.Write(p2Board[i + x] + "|");
                        }
                        Console.WriteLine();
                    }
                }
                else if (selection.Equals("P1Hit"))
                {
                    for (int x = 0; x < 10; x++)
                    {
                        for (int i = 0; i < 10; i++)
                        {
                            Console.Write(p1Hit[i + x] + "|");
                        }
                        Console.WriteLine();
                    }
                }
                else
                {

                    for (int x = 0; x < 10; x++)
                    {
                        for (int i = 0; i < 10; i++)
                        {
                            Console.Write(p2Hit[i + x] + "|");
                        }
                        Console.WriteLine();
                    }

                }

            }
        //testing Pass 03/20 AAV 
            static void introduction()
            {
                Console.Title = "Battleship";

                Console.WriteLine("Welcome to Battleship.\n\nPress any key to continue.");
                Console.ReadLine();
            }

        public override string ToString()
        {
            return base.ToString();
        }

        public override bool Equals(object obj)
        {
            return base.Equals(obj);
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
    }
    }
